package Payment;

public interface Search {
    boolean search_by_movie();
    boolean search_by_genre();
    boolean search_by_language();
}
